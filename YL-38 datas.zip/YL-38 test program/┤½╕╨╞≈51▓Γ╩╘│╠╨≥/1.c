/******************************************
snsor trigger test
MCU��STC89C52
baud rate��9600
*****************************************/
#include <reg52.h>
unsigned char date;
#define uchar unsigned char
#define uint unsigned int
sbit key1=P0^1;


/* function declare -----------------------------------------------*/
void delay(uint z);
void Initial_com(void);

//***********************************************************

/*
********************************************************************************
** Functio Name �� delay(uint z)
** Function function �� delay function
********************************************************************************
*/
void delay(uint z)
{																							   
    uint i,j;
    for(i=z;i>0;i--)
        for(j=110;j>0;j--);
} 


//******************************

//*****searil port init function ***********

//******************************
void Initial_com(void)
{
 EA=1;        //enable interrupt
 ES=1;        //enable searial port interrupt
 ET1=1;        //enable timer T1 interrupt
 TMOD=0x20;   //timer T1��generate baud rate at mode 2
 PCON=0x00;   //SMOD=0
 SCON=0x50;   // mode 1 control by timer
 TH1=0xfd;    //baud rate set to 9600
 TL1=0xfd;
 TR1=1;       //open timer T1 control bit

}




//*************************
//**********������*********
//*************************
main()
{
	 Initial_com();
	 while(1)
	 {
	
	 	 if(key1==0)
		{
			delay();	  //������
			if(key1==0)	  //ȷ�ϴ���
			{
				 SBUF=0X01;
				 delay(200);
				
			
			}
	   
		}
		 
		  if(RI)
		  {
			date=SBUF;    //��Ƭ������
			SBUF=date;    //��Ƭ������
			RI=0;
		  }
		
		
	  }
}